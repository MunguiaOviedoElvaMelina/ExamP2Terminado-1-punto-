package com.example.agendaep

class Agenda (val nombre:String,val nocontrol:String)